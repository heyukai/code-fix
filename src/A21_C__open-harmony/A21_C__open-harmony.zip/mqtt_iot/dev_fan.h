#ifndef __DEV_FAN_H__
#define __DEV_FAN_H__
// 驱动电机函数
int motor_speed(int speed);
// 电机初始化
int motor_init();
//led 驱动初始化
int led_init();
//led 驱动函数
int led_control(int set);
#endif