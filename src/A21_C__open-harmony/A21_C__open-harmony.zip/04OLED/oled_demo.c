#include <stdio.h>
#include <unistd.h>
#include <iot_gpio.h>
#include <iot_gpio_ex.h>
#include <iot_spi.h>
#include "oled.h"
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "gui.h"

#define OLED_TASK_STACK_SIZE 4096
char temp_str[40];
char humi_str[40];
extern float g_temp;
extern float g_humi;
 /* task处理函数 */
void OLedTask(void * para)
{
    printf("OLED task \r\n");
    OLED_Init();               //初始化OLED  
    while(1){
        OLED_Clear(0);    
        memset(temp_str,0,sizeof(temp_str));
        memset(humi_str,0,sizeof(humi_str));

        sprintf(temp_str,"温度:%.02f",g_temp);
        sprintf(humi_str,"湿度:%.02f",g_humi);
       // printf("2==> temp=%f,humi=%f\n",g_temp,g_humi);


        showText(0,0,16,temp_str);
        showText(0,18,16,humi_str);

        OLED_Display();
        sleep(5);
    }
   
    return NULL;
}
 /* 创建oled任务函数 */
void oled_demo(void)
{    
    int ret;
    oled_gpio_io_init();
    screen_spi_master_init(0); 
    osThreadAttr_t attr;
 
    attr.name = "OLedTask";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = OLED_TASK_STACK_SIZE;
    attr.priority = 20;
    if (osThreadNew((osThreadFunc_t)OLedTask, NULL, &attr) == NULL) {
        printf("[OLedExample] Falied to create LedTask1!\n");
    }
}
void showText_1(int x,int y,int font_size,char *str){
    char *tmp_str = str;
    int cur_x=x;
    int cur_y=y;
    
    while(*tmp_str != '\0')
    {
        unsigned char csize = font_size;
        if(tmp_str[0] > 0){
           if(font_size == 16) {
                csize = font_size/2;
            }else if(font_size == 8){
                csize = font_size/2+2;
            }
            GUI_ShowChar(cur_x,cur_y,tmp_str[0],font_size,1);
            tmp_str++;
        }else{
            if(font_size == 16){
                GUI_ShowFont16(cur_x,cur_y,tmp_str,1);
            }else if(font_size == 24){
                //参照showChinese自己实现
            }
            tmp_str +=3;
        }
        cur_x += csize;
        if(cur_x > WIDTH-font_size)
        {
            cur_x=0;
            cur_y+=font_size;
        }
    }
}

APP_FEATURE_INIT(oled_demo);