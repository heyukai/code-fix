#include <stdio.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "los_swtmr.h"
#include "iot_gpio.h"
#include "iot_gpio_ex.h"
#include "iot_pwm.h"
#define MOTOR_GPIO_IDX 2
#define MOTOR_PWM_CHN 2
int g_motor_level;
#define LED_GPIO 6
//led 驱动初始化
int led_init()
{
IoTGpioInit(LED_GPIO);
IoTGpioSetFunc(LED_GPIO, 0);
IoTGpioSetDir(LED_GPIO,IOT_GPIO_DIR_OUT);
IoTGpioSetOutputVal(LED_GPIO, 0);
}
//led 驱动函数
int led_control(int set)
{
IoTGpioSetOutputVal(LED_GPIO, set);
}
// 驱动电机函数
int motor_speed(int speed){
if(speed <0){
speed = 0;
}
int level = (speed > 5) ? 5 : speed ;
if(speed == 0){
//close motor
IoTPwmStop(MOTOR_PWM_CHN);
}else{
IoTPwmStart(MOTOR_PWM_CHN, level, 40000);
}
g_motor_level = level;
}
// 电机初始化
int motor_init()
{
IoTGpioInit(MOTOR_GPIO_IDX);
IoTGpioSetFunc(MOTOR_GPIO_IDX, IOT_GPIO_FUNC_GPIO_2_PWM2_OUT);
IoTGpioSetDir(MOTOR_GPIO_IDX,IOT_GPIO_DIR_OUT);
IoTPwmInit(MOTOR_PWM_CHN);
}