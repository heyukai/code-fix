#include <stdio.h>
#include "oled.h"
#include "gui.h"
#include "test.h"
    
void showText(int x,int y,int font_size,char *str){
    char *tmp_str = str;
    int cur_x=x;
    int cur_y=y;
    while(*tmp_str != '\0')
    {
        unsigned char csize = font_size;
        if(tmp_str[0] > 0){
           if(font_size == 16) {
                csize = font_size/2;
            }else if(font_size == 8){
                csize = font_size/2+2;
            }
      
            GUI_ShowChar(cur_x,cur_y,tmp_str[0],font_size,1);
            tmp_str++;
        }else{
            if(font_size == 16){
                GUI_ShowFont16(cur_x,cur_y,tmp_str,1);
            }else if(font_size == 24){
                //参照showChinese自己实现
            }
            tmp_str +=3;
        
        }
        
        cur_x += csize;
        if(cur_x > WIDTH-font_size)
		{
			cur_x=0;
			cur_y+=font_size;
		}
    }
}

void test_led_screen(void)
{	
  
    printf("before oled clear \r\n");
    OLED_Init();			   //初始化OLED  
    
    OLED_Clear(0);   
  
    while(1){
        OLED_Clear(0);  

        GUI_DrawLine(0,1,10,20,1);
        GUI_DrawTriangel(10,10,20,30,40,40,1);
        GUI_ShowString(40,20,"OpenHarmony",16,1);
        OLED_Display();
        sleep(3);
    }
   
    OLED_Display();
   
}

